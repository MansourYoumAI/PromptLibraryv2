import streamlit as st
from lib.data_store import list_bookmarks
def qp(key, default=None):
    try:
        return st.query_params.get(key, [default])[0]
    except Exception:
        try:
            return st.experimental_get_query_params().get(key, [default])[0]
        except Exception:
            return default

def link_btn(label, url):
    if hasattr(st, "link_button"):
        st.link_button(label, url)
    else:
        st.markdown(f"[{label}]({url})")

def toast(msg):
    if hasattr(st, "toast"):
        st.toast(msg)
    else:
        st.info(msg)


def render():
    st.title("My saved prompts")
    items = list_bookmarks(st.session_state.get('user_key','guest'))
    if not items:
        st.info("No bookmarks yet.")
        return
    for p in items:
        st.markdown(f"**{p['title']}** — {p.get('category_name','')}")
        link_btn("Open", f"/?view=prompt&id={p['id']}")
